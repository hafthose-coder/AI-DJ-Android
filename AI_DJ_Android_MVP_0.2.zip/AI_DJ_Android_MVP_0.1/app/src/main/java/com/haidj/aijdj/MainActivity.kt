package com.haidj.aijdj

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private data class Track(val name: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AIDJApp() }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun playTrack(track: Track, onFinished: () -> Unit) {
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(this@MainActivity, track.uri)
            setOnPreparedListener { start() }
            setOnCompletionListener { onFinished() }
            setOnErrorListener { _, _, _ -> onFinished(); true }
            prepareAsync()
        }
    }

    private fun stopTrack() {
        player?.stop()
        player?.release()
        player = null
    }

    @Composable
    private fun AIDJApp() {
        var tracks by remember { mutableStateOf(emptyList<Track>()) }
        var duration by remember { mutableStateOf(15f) }
        var energy by remember { mutableStateOf(0.75f) }
        var ready by remember { mutableStateOf(false) }
        var playingIndex by remember { mutableStateOf<Int?>(null) }
        var status by remember { mutableStateOf("Add audio files you own or are licensed to use.") }

        val picker = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenMultipleDocuments()
        ) { uris ->
            if (uris.isNotEmpty()) {
                val newTracks = uris.map { uri -> Track(displayName(uri), uri) }
                tracks = (tracks + newTracks).distinctBy { it.uri.toString() }
                ready = false
                status = "${tracks.size} track(s) loaded."
            }
        }

        fun playFrom(index: Int) {
            if (tracks.isEmpty()) return
            val safeIndex = index.coerceIn(0, tracks.lastIndex)
            playingIndex = safeIndex
            status = "Playing: ${tracks[safeIndex].name}"
            playTrack(tracks[safeIndex]) {
                val next = safeIndex + 1
                if (next < tracks.size) playFrom(next) else {
                    playingIndex = null
                    status = "Playback finished."
                }
            }
        }

        MaterialTheme(colorScheme = darkColorScheme(
            primary = Color(0xFF8B7CFF),
            background = Color(0xFF0B0B10),
            surface = Color(0xFF15151D)
        )) {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.padding(20.dp).fillMaxSize()) {
                    Text("AI DJ", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text("Android MVP • local audio test", color = Color.LightGray)
                    Spacer(Modifier.height(18.dp))

                    Button(
                        onClick = { picker.launch(arrayOf("audio/*")) },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("ADD AUDIO FILES") }

                    Spacer(Modifier.height(14.dp))
                    Text("TRACKS", fontWeight = FontWeight.Bold, color = Color(0xFFB9B0FF))

                    if (tracks.isEmpty()) {
                        Card(Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(14.dp)) {
                            Text("No tracks yet. Add 2 or more audio files to test the MVP.", Modifier.padding(16.dp), color = Color.LightGray)
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                            itemsIndexed(tracks) { i, track ->
                                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(14.dp)) {
                                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${i + 1}", Modifier.width(30.dp), color = Color(0xFF8B7CFF))
                                        Text(track.name, Modifier.weight(1f), fontSize = 16.sp)
                                        TextButton(onClick = {
                                            if (playingIndex == i) stopTrack()
                                            tracks = tracks.toMutableList().also { it.removeAt(i) }
                                            playingIndex = null
                                            ready = false
                                        }) { Text("Remove") }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Text("Mix duration: ${duration.toInt()} min")
                    Slider(duration, { duration = it }, valueRange = 5f..60f, steps = 10)
                    Text("Energy: ${(energy * 100).toInt()}%")
                    Slider(energy, { energy = it })
                    Spacer(Modifier.height(6.dp))

                    Button(
                        onClick = {
                            ready = true
                            status = "Mix plan created: ${duration.toInt()} min • ${tracks.size} tracks • energy ${(energy * 100).toInt()}%."
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        enabled = tracks.size >= 2
                    ) { Text("CREATE MIX PLAN", fontWeight = FontWeight.Bold) }

                    Spacer(Modifier.height(8.dp))
                    Text(status, color = Color.LightGray, fontSize = 13.sp)

                    if (ready && tracks.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Card(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("YOUR MIX IS READY", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("${duration.toInt()}:00 • ${tracks.size} tracks", color = Color.LightGray)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { playFrom(0) }) { Text(if (playingIndex == null) "PLAY" else "RESTART") }
                                    OutlinedButton(onClick = {
                                        stopTrack(); playingIndex = null; status = "Playback stopped."
                                    }) { Text("STOP") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun displayName(uri: Uri): String {
        var name: String? = null
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0)
        }
        return name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Audio track"
    }
}
