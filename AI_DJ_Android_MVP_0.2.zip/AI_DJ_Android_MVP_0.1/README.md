# AI DJ — Android MVP 0.2

A buildable Android Studio MVP for testing the AI-DJ product concept.

## What works now
- Android app UI built with Kotlin + Jetpack Compose.
- Select multiple local audio files using the Android file picker.
- Track list with add/remove.
- Mix duration control: 5–60 minutes.
- Energy control.
- Create a mix plan.
- Play the selected tracks sequentially with Android MediaPlayer.
- Stop/restart playback.

## Important
This is a prototype for testing the product flow. It does **not** yet perform true AI DJ mixing, BPM/key detection, beat matching, crossfades, EQ automation, or audio rendering into a new MP3.

For the first legal/technical test, use audio files you own or are licensed to use.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone with USB debugging enabled, or create an emulator.
4. Run the `app` configuration.
5. To create an APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

Requirements:
- Android Studio with Android SDK Platform 35.
- JDK 17+ (Android Studio's bundled JDK is recommended).
- minSdk 26.
